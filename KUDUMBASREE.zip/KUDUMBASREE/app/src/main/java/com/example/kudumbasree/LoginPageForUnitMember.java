package com.example.kudumbasree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginPageForUnitMember extends AppCompatActivity {
    Button prelogin;
    TextView textview,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page_for_unit_member);

        prelogin=findViewById(R.id.loginpre);
        textview=findViewById(R.id.createnew);
        password=findViewById(R.id.forgt);

        prelogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginPageForUnitMember.this,homescreenmember.class);
                startActivity(intent);

            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent=new Intent(LoginPageForUnitMember.this,forgtpage.class);
                startActivity(intent);

            }
        });
        textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginPageForUnitMember.this,registrationpage.class);
                startActivity(intent);

            }
        });
    }
}