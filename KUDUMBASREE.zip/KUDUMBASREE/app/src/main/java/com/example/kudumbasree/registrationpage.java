package com.example.kudumbasree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class registrationpage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button regbtn;
    String[] district = {"Trivardrum","Kottayam","Ernakulam","Thrissur","Idukkki","Palakkad","Wayanad"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrationpage);

        regbtn = findViewById(R.id.dia_submit);
        Spinner spin = findViewById(R.id.spinner);

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(registrationpage.this, LoginPage.class);
                startActivity(intent);


            }
        });

        spin.setOnItemSelectedListener(this);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, district);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLUE);
        ((TextView) adapterView.getChildAt(0)).setTextSize(15);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    }