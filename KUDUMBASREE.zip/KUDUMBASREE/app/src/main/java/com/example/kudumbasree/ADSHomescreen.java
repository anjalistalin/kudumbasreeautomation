package com.example.kudumbasree;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class ADSHomescreen extends AppCompatActivity {

    DrawerLayout drawerads;
    ImageView menuads, notifia;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adshomescreen);

        drawerads = findViewById(R.id.drawer_adsid);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerads, R.string.drawer_open, R.string.drawer_close);
        drawerads.addDrawerListener(toggle);
        toggle.syncState();
        menuads = findViewById(R.id.navads);
        notifia = findViewById(R.id.notifiads);
        NavigationView navigationView = findViewById(R.id.nav_viewads);
        navigationView.setCheckedItem(R.id.nav_viewads);
        BottomNavigationView bottomNavads = findViewById(R.id.bottomNavigationViewads);

        bottomNavads.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();
                if (itemId == R.id.homeads) {
                    selectedFragment = new adshome();
                } else if (itemId == R.id.searchads) {
                    selectedFragment = new adssearch();
                } else if (itemId == R.id.profileads) {
                    selectedFragment = new adsprofile();
                } else if (itemId == R.id.settingsads) {
                    selectedFragment = new adssettings();
                }
                // It will help to replace the
                // one fragment to other.
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.frameads, selectedFragment).commit();
                }
                return false;
            }
        });
        menuads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerads.openDrawer(GravityCompat.START);
            }

        });
    }
    private void replaceFragment(Fragment fragment) {


        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame,fragment);
        fragmentTransaction.commit();

        }

    }
