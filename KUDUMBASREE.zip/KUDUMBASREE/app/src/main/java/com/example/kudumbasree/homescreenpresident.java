package com.example.kudumbasree;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class homescreenpresident extends AppCompatActivity  {
    DrawerLayout drawer;
    ImageView menu, notifi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreenpresident);
        drawer = findViewById(R.id.drawer_id);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, R.string.drawer_open, R.string.drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        menu = findViewById(R.id.nav);
        notifi = findViewById(R.id.notifi);


        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setCheckedItem(R.id.nav_view);

        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.memberlist) {
                   Intent intent = new Intent(homescreenpresident.this,MemberList.class);
                   startActivity(intent);
                }
                else if (itemId == R.id.loan) {
                    Intent intent1 = new Intent(homescreenpresident.this,Loan.class);
                    startActivity(intent1);
                }
                else if (itemId == R.id.report) {
                    Intent intent2 = new Intent(homescreenpresident.this,Reportsubmission.class);
                    startActivity(intent2);
                }
                else if (itemId == R.id.expense) {
                    Intent intent3 = new Intent(homescreenpresident.this,Expense.class);
                    startActivity(intent3);
                }
                else if (itemId == R.id.jobalert) {
                    Intent intent4 = new Intent(homescreenpresident.this,JobAlert.class);
                    startActivity(intent4);
                }
                else if (itemId == R.id.logout) {
                    Intent intent5 = new Intent(homescreenpresident.this,LogOut.class);
                    startActivity(intent5);
                }
           /*     switch (item.getItemId())
                {
                    case R.id.memberlist:
                        Intent intent = new Intent(homescreenpresident.this,MemberList.class);
                        startActivity(intent);
                        return true;

                    case R.id.loan:
                        Intent intent1 = new Intent (homescreenpresident.this,Loan.class);
                        startActivity(intent1);
                        return true;

                    case R.id.expense:
                        Intent intent3 = new Intent(homescreenpresident.this,Expense.class);
                        startActivity(intent3);
                        return  true;

                    case R.id.jobalert:
                        Intent intent4 = new Intent(homescreenpresident.this,JobAlert.class);
                        startActivity(intent4);
                        return true;

                    case R.id.logout:
                        Intent intent5 = new Intent(homescreenpresident.this,LogOut.class);
                        return true;

                }*/

                return false;
            }
        });



        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();
                if (itemId == R.id.home) {
                    selectedFragment = new home();
                }
                else if (itemId == R.id.search) {
                    selectedFragment = new search();
                } else if (itemId == R.id.profile) {
                    selectedFragment = new profile();
                } else if (itemId == R.id.settings) {
                    selectedFragment = new settings();
                }
                // It will help to replace the
                // one fragment to other.
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.frame, selectedFragment).commit();
                }
                return false;
            }
        });
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {drawer.openDrawer(GravityCompat.START);}
        });
    }

    private void replaceFragment(Fragment fragment) {


            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame,fragment);
            fragmentTransaction.commit();


    }


}