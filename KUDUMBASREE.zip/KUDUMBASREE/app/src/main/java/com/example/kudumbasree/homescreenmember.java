package com.example.kudumbasree;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class homescreenmember extends AppCompatActivity {

    DrawerLayout drawer;
    ImageView menum, notifim;
    Button mviewat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreenmember);

        drawer = findViewById(R.id.drawer_idmem);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, R.string.drawer_open, R.string.drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        menum = findViewById(R.id.navmem);
        notifim = findViewById(R.id.notifimem);
        mviewat=findViewById(R.id.matv);
        NavigationView navigationView = findViewById(R.id.nav_viewmem);
        navigationView.setCheckedItem(R.id.nav_viewmem);
        BottomNavigationView bottomNavmem = findViewById(R.id.bottomNavigationViewmem);



        bottomNavmem.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();
                if (itemId == R.id.homemem) {
                    selectedFragment = new homemem();
                }
                else if (itemId == R.id.searchmem) {
                    selectedFragment = new searchmem();
                } else if (itemId == R.id.profilemem) {
                    selectedFragment = new profilemem();
                } else if (itemId == R.id.settingsmem) {
                    selectedFragment = new settingsmem();
                }
                // It will help to replace the
                // one fragment to other.
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.framemem, selectedFragment).commit();
                }
                return false;
            }
        });


        menum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(GravityCompat.START);
            }
        });
    }


    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framemem, fragment);
        fragmentTransaction.commit();
    }
}